body { font-family: Arial, sans-serif; margin: 20px; }
nav a { margin-right: 15px; }

